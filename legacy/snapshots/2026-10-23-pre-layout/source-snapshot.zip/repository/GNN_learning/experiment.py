"""Unified experiment CLI: generate / train / evaluate / run.

Use python -m GNN_learning.experiment --help from the repository root.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import sys

if not __package__:
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from GNN_learning.experiment_config import load_config
from GNN_learning.generate_datasets import create_dataset
from GNN_learning.train import train_gnn,resolve_training_config
from GNN_learning.evaluate import evaluate
from GNN_learning.runtime import load_split


def _common(parser,execution_options=True):
    parser.add_argument('--config')
    parser.add_argument('--data-root')
    if execution_options:
        parser.add_argument('--output-root')
        parser.add_argument('--device',choices=('auto','cpu','cuda'),default='auto')
        parser.add_argument('--threads',type=int)


def _training(parser):
    for name in ('beta','gamma','kappa','eta','lr','tau-init','tau-decay'):
        parser.add_argument('--'+name,type=float)
    parser.add_argument('--epochs',type=int)
    parser.add_argument('--run-name')


def _overrides(args):
    return {name:getattr(args,name) for name in ('beta','gamma','kappa','eta','lr','tau_init','tau_decay','epochs')}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command',required=True)
    generate = commands.add_parser('generate',help='Generate versioned datasets without overwriting existing files')
    _common(generate,False)
    generate.add_argument('--split',nargs='+',default=['train','val','test'])
    generate.add_argument('--num-graphs',type=int)
    generate.add_argument('--seed-offset',type=int,default=0)
    train = commands.add_parser('train',help='Train, resume an existing schedule, or initialize a new fine-tuning run')
    _common(train)
    _training(train)
    group = train.add_mutually_exclusive_group()
    group.add_argument('--resume')
    group.add_argument('--init-from')
    train.add_argument('--stop-after-epoch',type=int)
    evaluation = commands.add_parser('evaluate',help='Evaluate a specific versioned checkpoint')
    _common(evaluation)
    evaluation.add_argument('--checkpoint',required=True)
    evaluation.add_argument('--split',default='test')
    evaluation.add_argument('--max-graphs',type=int)
    evaluation.add_argument('--evaluation-name')
    run = commands.add_parser('run',help='Generate -> train -> load best checkpoint -> Dense/BFS/GNN -> reports')
    _common(run)
    _training(run)
    run.add_argument('--reuse-data',action='store_true')
    run.add_argument('--max-graphs',type=int)
    run.add_argument('--evaluation-name')
    args = parser.parse_args(argv)
    if args.command == 'generate':
        cfg = load_config(args.config)
        paths = []
        for split in args.split:
            count = args.num_graphs if args.num_graphs is not None else cfg.split_sizes.get(split)
            if count is None:
                parser.error(f'No configured graph count for {split}')
            paths.append(create_dataset(split,count,seed_offset=args.seed_offset,settings=cfg,output_root=args.data_root))
        return paths
    if args.command == 'train':
        return train_gnn(config_path=args.config,data_root=args.data_root,output_root=args.output_root,
                         resume=args.resume,init_from=args.init_from,run_name=args.run_name,
                         device=args.device,threads=args.threads,stop_after_epoch=args.stop_after_epoch,
                         **_overrides(args))
    if args.command == 'evaluate':
        return evaluate(checkpoint=args.checkpoint,config_path=args.config,data_root=args.data_root,
                        output_root=args.output_root,device=args.device,threads=args.threads,
                        split=args.split,max_graphs=args.max_graphs,evaluation_name=args.evaluation_name)
    cfg = resolve_training_config(args.config,**_overrides(args))
    for split in ('train','val','test'):
        if cfg.split_sizes.get(split,0) < 1:
            raise ValueError('run requires nonempty train, val and test splits')
    if args.reuse_data:
        for split in ('train','val','test'):
            load_split(cfg,split,args.data_root)
    else:
        if any(cfg.dataset_path(split,args.data_root).exists() or cfg.dataset_path(split,args.data_root).with_suffix('.json').exists()
               for split in ('train','val','test')):
            raise FileExistsError('Pipeline data already exists; explicitly pass --reuse-data after verifying its identity')
        for split in ('train','val','test'):
            create_dataset(split,cfg.split_sizes[split],settings=cfg,output_root=args.data_root)
    models = train_gnn(settings=cfg,data_root=args.data_root,output_root=args.output_root,
                       run_name=args.run_name,device=args.device,threads=args.threads)
    report = evaluate(checkpoint=models/'best_checkpoint.pt',settings=cfg,data_root=args.data_root,
                      output_root=args.output_root,device=args.device,threads=args.threads,
                      max_graphs=args.max_graphs,evaluation_name=args.evaluation_name)
    return {'models':models,'evaluation':report}


if __name__ == '__main__':
    main()
