"""Static localization graph generation with the versioned global-index contract.

LOS follows the paper's Gaussian model without range clipping. NLOS is explicit.
"""
from __future__ import annotations
from dataclasses import asdict, replace
import warnings
import torch

if __package__:
    from .experiment_config import DataConfig, load_config
    from .data_schema import (GRAPH_VERSION, encode_measurements, graph_diagnostics,
                              normalize_covariances, validate_record)
else:
    from experiment_config import DataConfig, load_config
    from data_schema import (GRAPH_VERSION, encode_measurements, graph_diagnostics,
                             normalize_covariances, validate_record)

SCENARIO_ANCHORS = {'normal': 16, 'hard': 5, 'challenge': 4}
AGENT_DISTRIBUTIONS = ('uniform', 'clustered')
LEGACY_LAYOUTS = {'normal': 'grid4', 'hard': 'corners_center', 'challenge': 'corners'}


def anchor_positions(settings):
    size = settings.area_size
    corners = torch.tensor([[0., 0.], [size, 0.], [0., size], [size, size]], dtype=torch.float32)
    if settings.anchor_layout == 'corners':
        return corners
    if settings.anchor_layout == 'corners_center':
        return torch.cat((corners, torch.tensor([[size / 2, size / 2]], dtype=torch.float32)))
    grid = torch.linspace(0., size, 4, dtype=torch.float32)
    return torch.stack(torch.meshgrid(grid, grid, indexing='ij'), dim=-1).reshape(-1, 2)


def generate_graph(settings, num_agents, *, generator=None, sample_id='standalone', metadata=None):
    if not isinstance(settings, DataConfig):
        raise TypeError('settings must be a DataConfig')
    if isinstance(num_agents, bool) or not isinstance(num_agents, int) or num_agents < 1:
        raise ValueError('num_agents must be a positive integer')
    anchors = anchor_positions(settings)
    if settings.agent_distribution == 'uniform':
        truth = torch.rand((num_agents, 2), generator=generator, dtype=torch.float32) * settings.area_size
    else:
        truth = (torch.randn((num_agents, 2), generator=generator, dtype=torch.float32)
                 * settings.area_size * settings.cluster_std_ratio + settings.area_size / 2)
        margin = settings.area_size * settings.cluster_margin_ratio
        truth = truth.clamp(margin, settings.area_size - margin)
    cov = normalize_covariances(settings.initial_covariance, num_agents)
    noise = torch.randn((num_agents, 2, 1), generator=generator, dtype=torch.float32)
    initial = truth + (torch.linalg.cholesky(cov) @ noise).squeeze(-1)
    positions = torch.cat((initial, anchors))
    true_positions = torch.cat((truth, anchors))
    n = positions.shape[0]
    candidate = torch.triu_indices(n, n, offset=1)
    u, v = candidate
    distances = (true_positions[u] - true_positions[v]).norm(dim=1)
    radii = torch.where(v < num_agents, distances.new_tensor(settings.agent_comm_radius),
                        distances.new_tensor(settings.anchor_comm_radius))
    keep = (u < num_agents) & (distances < radii)
    ei = candidate[:, keep].contiguous()
    d = distances[keep]
    std = settings.base_noise_std + settings.distance_noise_scale * d
    measurements = d + torch.randn(d.shape, generator=generator, dtype=torch.float32) * std
    nlos = torch.zeros(ei.shape[1], dtype=torch.bool)
    if settings.enable_nlos:
        agent_edges = torch.where(ei[1] < num_agents)[0]
        count = int(agent_edges.numel() * settings.nlos_ratio)
        chosen = agent_edges[torch.randperm(agent_edges.numel(), generator=generator)[:count]]
        nlos[chosen] = True
        measurements[chosen] += (settings.nlos_bias_min + torch.rand(count, generator=generator, dtype=torch.float32)
                                  * (settings.nlos_bias_max - settings.nlos_bias_min))
    inputs = {
        'initial_positions': positions,
        'initial_covariances': cov,
        'is_anchor': torch.arange(n) >= num_agents,
        'edge_index': ei,
        'measurements': encode_measurements(measurements),
        'measurement_variances': encode_measurements(std.square(), positive=True),
        'communication_cost_scale': settings.communication_cost_scale,
        'measurement_encoding': settings.measurement_encoding,
    }
    record = {
        'schema_version': GRAPH_VERSION, 'sample_id': sample_id, 'inputs': inputs,
        'targets': {'agent_positions': truth},
        'metadata': {'data_config': asdict(settings), 'units': {'position': 'm', 'variance': 'm^2'},
                     'measurement_model': 'nlos_positive_bias' if settings.enable_nlos else 'los_gaussian',
                     'variance_assumption': 'known variance from physical true distance',
                     'range_clipped': False},
        'diagnostics': {'is_nlos_edge': nlos, **graph_diagnostics(inputs)},
    }
    if metadata:
        record['metadata'].update(metadata)
    return validate_record(record, require_targets=True)


def generate_localization_network(num_agents=30, num_anchors=None, area_size=None,
                                  comm_radius=None, base_noise=None, noise_scale=None,
                                  init_pos_cov=None, scenario_type=None,
                                  agent_distribution=None, enable_nlos=None,
                                  nlos_ratio=None, nlos_bias_range=None, *,
                                  anchor_comm_radius=None, settings=None,
                                  generator=None, sample_id='standalone'):
    """Compatibility entry name; returns a v1 global-index record.

    Scenario never implicitly changes radius or distribution.
    """
    settings = settings if settings is not None else load_config().data
    updates = {}
    for name, value in (('area_size', area_size), ('agent_comm_radius', comm_radius),
                        ('anchor_comm_radius', anchor_comm_radius), ('base_noise_std', base_noise),
                        ('distance_noise_scale', noise_scale), ('initial_covariance', init_pos_cov),
                        ('enable_nlos', enable_nlos), ('nlos_ratio', nlos_ratio)):
        if value is not None:
            updates[name] = value
    if scenario_type is not None:
        if scenario_type not in LEGACY_LAYOUTS:
            raise ValueError(f'Unknown legacy scenario {scenario_type}')
        updates.update(scenario=scenario_type, anchor_layout=LEGACY_LAYOUTS[scenario_type])
    if agent_distribution == 'auto':
        raise ValueError("'auto' was removed: specify uniform or clustered explicitly")
    if agent_distribution is not None:
        updates['agent_distribution'] = agent_distribution
    if nlos_bias_range is not None:
        updates.update(nlos_bias_min=nlos_bias_range[0], nlos_bias_max=nlos_bias_range[1])
    settings = replace(settings, **updates)
    if num_anchors is not None and num_anchors != settings.num_anchors:
        raise ValueError('num_anchors conflicts with the explicit anchor_layout')
    if updates:
        warnings.warn('Legacy generator overrides used; radii/distribution are now explicit.',
                      DeprecationWarning, stacklevel=2)
    return generate_graph(settings, num_agents, generator=generator, sample_id=sample_id)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Inspect one v1 localization graph')
    parser.add_argument('--config')
    parser.add_argument('--num-agents', type=int, default=30)
    parser.add_argument('--plot', action='store_true')
    args = parser.parse_args()
    cfg = load_config(args.config)
    record = generate_graph(cfg.data, args.num_agents,
                            generator=torch.Generator().manual_seed(cfg.seed))
    print(f"{cfg.experiment_id}: agents={args.num_agents}, anchors={cfg.data.num_anchors}, "
          f"physical_edges={record['inputs']['edge_index'].shape[1]}, "
          f"unanchored_agents={record['diagnostics']['num_unanchored_agents']}")
    if args.plot:
        if __package__:
            from .visualize_topology import plot_topology_comparison
        else:
            from visualize_topology import plot_topology_comparison
        weights = torch.ones(record['inputs']['edge_index'].shape[1])
        plot_topology_comparison(record, weights, weights)
