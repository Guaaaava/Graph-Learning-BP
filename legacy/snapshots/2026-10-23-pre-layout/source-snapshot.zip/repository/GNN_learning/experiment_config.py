"""Validated, serializable experiment settings (no torch import required)."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Optional

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_VERSION = 'gib4cl.config.v1'
MODEL_VERSION = 'gib4cl.gnn.symmetric-logistic.v1'
BP_VERSION = 'gib4cl.bp.fixed-prior-cavity.v1'
MEASUREMENT_ENCODING = 'ieee754-binary32-canonical-finite'
ANCHOR_COUNTS = {'grid4': 16, 'corners_center': 5, 'corners': 4}


def canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False)


def fingerprint(value):
    return hashlib.sha256(canonical_json(value).encode('utf-8')).hexdigest()


def validate_name(value, field_name):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', value):
        raise ValueError(f'{field_name} must contain 1-80 ASCII letters/digits/_/- and start with a letter/digit')
    return value


def _positive(value, name, allow_zero=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{name} must be finite')
    if value < 0 or (not allow_zero and value == 0):
        raise ValueError(f'{name} must be {"nonnegative" if allow_zero else "positive"}')


def _integer(value, name, minimum=1):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f'{name} must be an integer >= {minimum}')


@dataclass(frozen=True)
class DataConfig:
    # Scenario is descriptive. Layout, radii, and distribution are independent.
    scenario: str = 'challenge'
    anchor_layout: str = 'corners'
    agent_distribution: str = 'clustered'
    num_agents_min: int = 25
    num_agents_max: int = 35
    area_size: float = 100.0
    agent_comm_radius: float = 30.0
    anchor_comm_radius: float = 54.044011451988085
    cluster_std_ratio: float = 1.0 / 6.0
    cluster_margin_ratio: float = 0.1
    initial_covariance: object = 25.0
    base_noise_std: float = 0.5
    distance_noise_scale: float = 0.05
    enable_nlos: bool = False
    nlos_ratio: float = 0.15
    nlos_bias_min: float = 2.0
    nlos_bias_max: float = 10.0
    communication_cost_scale: float = 1.0
    measurement_encoding: str = MEASUREMENT_ENCODING

    def __post_init__(self):
        validate_name(self.scenario, 'scenario')
        if self.anchor_layout not in ANCHOR_COUNTS:
            raise ValueError(f'anchor_layout must be one of {tuple(ANCHOR_COUNTS)}')
        if self.agent_distribution not in ('uniform', 'clustered'):
            raise ValueError('agent_distribution must be explicit: uniform or clustered')
        _integer(self.num_agents_min, 'num_agents_min')
        _integer(self.num_agents_max, 'num_agents_max')
        if self.num_agents_max < self.num_agents_min:
            raise ValueError('num_agents_max must be >= num_agents_min')
        for name in ('area_size', 'cluster_std_ratio', 'base_noise_std', 'communication_cost_scale'):
            _positive(getattr(self, name), name)
        for name in ('agent_comm_radius', 'anchor_comm_radius', 'distance_noise_scale',
                     'nlos_bias_min', 'nlos_bias_max'):
            _positive(getattr(self, name), name, allow_zero=True)
        if not isinstance(self.enable_nlos, bool):
            raise ValueError('enable_nlos must be boolean')
        _positive(self.nlos_ratio, 'nlos_ratio', allow_zero=True)
        _positive(self.cluster_margin_ratio, 'cluster_margin_ratio', allow_zero=True)
        if self.nlos_ratio > 1 or self.cluster_margin_ratio >= 0.5:
            raise ValueError('nlos_ratio must be <= 1; cluster_margin_ratio must be < 0.5')
        if self.nlos_bias_max < self.nlos_bias_min:
            raise ValueError('nlos_bias_max must be >= nlos_bias_min')
        if self.measurement_encoding != MEASUREMENT_ENCODING:
            raise ValueError(f'Only {MEASUREMENT_ENCODING} is currently supported')
        cov = self.initial_covariance
        # JSON uses a scalar, two diagonal values, or a symmetric 2x2 matrix.
        if isinstance(cov, (int, float)):
            _positive(cov, 'initial_covariance')
        elif isinstance(cov, (tuple, list)) and len(cov) == 2:
            if all(isinstance(v, (int, float)) for v in cov):
                for v in cov:
                    _positive(v, 'initial_covariance diagonal')
                cov = tuple(cov)
            elif all(isinstance(v, (tuple, list)) and len(v) == 2 for v in cov):
                a, b = cov[0]
                c, d = cov[1]
                for value in (a, b, c, d):
                    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                        raise ValueError('initial_covariance matrix must be finite')
                if a <= 0 or d <= 0 or b != c or a * d - b * c <= 0:
                    raise ValueError('initial_covariance must be symmetric positive definite')
                cov = tuple(tuple(row) for row in cov)
            else:
                raise ValueError('Invalid initial_covariance shape')
            object.__setattr__(self, 'initial_covariance', cov)
        else:
            raise ValueError('initial_covariance must be scalar, length 2, or a 2x2 matrix')

    @property
    def num_anchors(self):
        return ANCHOR_COUNTS[self.anchor_layout]


@dataclass(frozen=True)
class ModelConfig:
    node_in_dim: int = 5
    edge_in_dim: int = 4
    hidden_dim: int = 64
    num_layers: int = 3
    architecture_version: str = MODEL_VERSION

    def __post_init__(self):
        if self.node_in_dim != 5 or self.edge_in_dim != 4:
            raise ValueError('The paper requires 5 node and 4 edge features')
        if self.architecture_version != MODEL_VERSION:
            raise ValueError(f'Only {MODEL_VERSION} is supported; old weights require retraining')
        _integer(self.hidden_dim, 'hidden_dim', 2)
        _integer(self.num_layers, 'num_layers')


@dataclass(frozen=True)
class TrainingConfig:
    epochs: int = 200
    batch_size: int = 32
    learning_rate: float = 0.001
    tau_init: float = 5.0
    tau_min: float = 0.1
    tau_decay: float = 0.98
    weight_decay: float = 1e-4
    max_grad_norm: float = 5.0
    lr_min: float = 1e-5
    deterministic: bool = True

    def __post_init__(self):
        _integer(self.epochs, 'epochs')
        _integer(self.batch_size, 'batch_size')
        for name in ('learning_rate', 'tau_init', 'tau_min', 'tau_decay'):
            _positive(getattr(self, name), name)
        if self.tau_min > self.tau_init or self.tau_decay > 1:
            raise ValueError('Require tau_min <= tau_init and tau_decay <= 1')
        _positive(self.weight_decay, 'weight_decay', allow_zero=True)
        _positive(self.max_grad_norm, 'max_grad_norm')
        _positive(self.lr_min, 'lr_min', allow_zero=True)
        if self.lr_min > self.learning_rate or not isinstance(self.deterministic, bool):
            raise ValueError('Require lr_min <= learning_rate and boolean deterministic')


@dataclass(frozen=True)
class ObjectiveConfig:
    # Formal experiment coefficients must be explicit; smoke coefficients live in their own preset.
    beta: Optional[float] = None
    gamma: Optional[float] = None
    kappa: Optional[float] = None
    eta: Optional[float] = None
    prediction_variance_floor: float = 1e-6
    compute_dtype: str = 'float64'

    def __post_init__(self):
        for name in ('beta', 'gamma', 'kappa', 'eta'):
            value = getattr(self, name)
            if value is not None:
                _positive(value, name, allow_zero=name != 'beta')
        _positive(self.prediction_variance_floor, 'prediction_variance_floor')
        if self.compute_dtype not in ('float32', 'float64'):
            raise ValueError('objective.compute_dtype must be float32 or float64')

    def require_ready(self):
        missing = [name for name in ('beta', 'gamma', 'kappa', 'eta') if getattr(self, name) is None]
        if missing:
            raise ValueError(f'Set explicit objective coefficients {missing}; old lambda/FIM settings are not substituted')
        return self


@dataclass(frozen=True)
class BPConfig:
    num_particles: int = 10000
    num_iterations: int = 3
    algorithm_version: str = BP_VERSION
    chunk_size: int = 256
    compute_dtype: str = 'float64'
    measurement_variance_floor: float = 0.0
    damping: float = 0.0
    message_tolerance: float = 1e-8
    early_stopping: bool = False

    def __post_init__(self):
        _integer(self.num_particles, 'num_particles', 2)
        _integer(self.num_iterations, 'num_iterations', 0)
        _integer(self.chunk_size, 'bp.chunk_size')
        if self.algorithm_version != BP_VERSION:
            raise ValueError(f'Only {BP_VERSION} is supported')
        if self.compute_dtype not in ('float32', 'float64'):
            raise ValueError('bp.compute_dtype must be float32 or float64')
        for name in ('measurement_variance_floor', 'damping', 'message_tolerance'):
            _positive(getattr(self, name), 'bp.'+name, allow_zero=True)
        if self.damping >= 1 or not isinstance(self.early_stopping, bool):
            raise ValueError('Require bp.damping < 1 and boolean early_stopping')


@dataclass(frozen=True)
class EvaluationConfig:
    outage_threshold: float = 3.0
    alpha: float = 0.05
    edge_threshold: float = 0.5
    bp_repeats: int = 1
    bootstrap_samples: int = 2000
    seed: int = 700
    include_information_proxy: bool = False
    covariance_rtol: float = 1e-12
    outage_thresholds: tuple = (.5, 1., 2., 3., 5., 10.)
    coverage_levels: tuple = (.5, .8, .9, .95, .99)
    ess_fraction_threshold: float = .1

    def __post_init__(self):
        _positive(self.outage_threshold, 'outage_threshold')
        _positive(self.alpha, 'alpha')
        if not self.alpha < 1:
            raise ValueError('alpha must be between 0 and 1')
        _positive(self.edge_threshold, 'edge_threshold')
        if self.edge_threshold >= 1:
            raise ValueError('edge_threshold must be in (0,1)')
        _integer(self.bp_repeats, 'bp_repeats')
        _integer(self.bootstrap_samples, 'bootstrap_samples', 0)
        _integer(self.seed, 'evaluation.seed', 0)
        if not isinstance(self.include_information_proxy, bool):
            raise ValueError('include_information_proxy must be boolean')
        _positive(self.covariance_rtol, 'covariance_rtol', allow_zero=True)
        if self.covariance_rtol >= 1:
            raise ValueError('covariance_rtol must be in [0,1)')
        for name, probability in (('outage_thresholds', False), ('coverage_levels', True)):
            values = getattr(self, name)
            if not isinstance(values, (list, tuple)) or not values:
                raise ValueError(name+' must be a nonempty sequence')
            for value in values:
                _positive(value, name)
                if probability and value >= 1:
                    raise ValueError(name+' values must be below 1')
            values = tuple(float(value) for value in values)
            if tuple(sorted(set(values))) != values:
                raise ValueError(name+' must be strictly increasing and unique')
            object.__setattr__(self, name, values)
        _positive(self.ess_fraction_threshold, 'ess_fraction_threshold')
        if self.ess_fraction_threshold > 1:
            raise ValueError('ess_fraction_threshold must be in (0,1]')


@dataclass(frozen=True)
class ExperimentConfig:
    config_version: str = CONFIG_VERSION
    experiment_id: str = 'challenge-los-v1'
    seed: int = 100
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    objective: ObjectiveConfig = field(default_factory=ObjectiveConfig)
    bp: BPConfig = field(default_factory=BPConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    split_sizes: dict = field(default_factory=lambda: {'train': 2000, 'val': 500, 'test': 500})

    def __post_init__(self):
        if self.config_version != CONFIG_VERSION:
            raise ValueError('Unsupported config_version')
        validate_name(self.experiment_id, 'experiment_id')
        _integer(self.seed, 'seed', 0)
        if not isinstance(self.split_sizes, dict) or not self.split_sizes:
            raise ValueError('split_sizes must be a nonempty dictionary')
        for split, count in self.split_sizes.items():
            validate_name(split, 'split')
            _integer(count, f'split_sizes.{split}', 0)

    def to_dict(self):
        return asdict(self)

    @property
    def data_fingerprint(self):
        # Training/metric changes must not alter the identity of the same observations.
        return fingerprint({'data': asdict(self.data), 'seed': self.seed})

    def dataset_path(self, split, output_root=None):
        validate_name(split, 'split')
        root = Path(output_root) if output_root is not None else REPO_ROOT / 'data'
        return root / self.experiment_id / self.data_fingerprint[:16] / f'{split}_dataset.pt'


def _construct(cls, value):
    if not isinstance(value, dict):
        raise ValueError(f'{cls.__name__} must be an object')
    unknown = set(value) - {f.name for f in fields(cls)}
    if unknown:
        raise ValueError(f'Unknown {cls.__name__} settings: {sorted(unknown)}')
    return cls(**value)


def config_from_dict(value):
    if not isinstance(value, dict):
        raise ValueError('Experiment configuration must be an object')
    value = dict(value)
    for name, cls in (('data', DataConfig), ('model', ModelConfig),
                      ('training', TrainingConfig), ('objective', ObjectiveConfig),
                      ('bp', BPConfig), ('evaluation', EvaluationConfig)):
        if name in value:
            value[name] = _construct(cls, value[name])
    return _construct(ExperimentConfig, value)


def load_config(path=None):
    if path is None:
        path = REPO_ROOT / 'configs' / 'challenge-los.json'
    with Path(path).open(encoding='utf-8') as handle:
        return config_from_dict(json.load(handle))


def sample_seed(master_seed, split, seed_offset, sample_number):
    """Stable per-sample streams: splits do not share a sequential RNG state."""
    validate_name(split, 'split')
    for value, name in ((master_seed, 'seed'), (seed_offset, 'seed_offset'), (sample_number, 'sample_number')):
        _integer(value, name, 0)
    encoded = f'gib4cl.sample.v1:{master_seed}:{split}:{seed_offset}:{sample_number}'
    return int.from_bytes(hashlib.sha256(encoded.encode('ascii')).digest()[:8], 'big') & ((1 << 63) - 1)
