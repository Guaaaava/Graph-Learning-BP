# GIB4CL 实验代码

当前已完成论文与数据格式对齐、新版训练目标、无向 GNN/Logistic 采样、粒子 BP、统一实验入口及评价指标。完整操作和边界见 [统一运行说明](docs/unified-experiment.md)，指标定义、统计分母和输出见 [评价指标说明](docs/evaluation-metrics.md)，进度见 [论文与实现清单](docs/paper-implementation-map.md)。

在项目依赖环境中，从本目录调用：

```text
python -B -m GNN_learning.experiment --help
python -B -m GNN_learning.experiment run --config configs/smoke-pipeline.json --data-root data/pipeline-demo --output-root outputs/pipeline-demo --device cpu --threads 1
```

Windows 本机解释器是 `.\.venv-data\Scripts\python.exe`，可替换上面的 `python`。

- `generate`：生成有版本、身份与校验值的数据，拒绝覆盖。
- `train`：训练；`--resume` 继续完整状态，`--init-from` 显式初始化新的微调实验。
- `evaluate`：必须指定 `--checkpoint`，对 Dense / BFS 森林 / GNN 使用共享先验粒子支持。
- `run`：生成→训练→读取最佳检查点→三种拓扑评估→报告。

评价输出 `results.json`、`report.md`、逐图/逐 BP 重复的 `trial_metrics.csv` 及包含均值、标准差、图数、置信区间和曲线的 `summary_metrics.csv`。覆盖精度与尾部、协方差校准/面积/高斯评分、通信节省、智能体三角形/环秩/连通性以及 ESS/收敛诊断。置信区间以独立图为簇；无效值和零分母均有明确口径。当前结果协议为 `gib4cl.evaluation.v2`。

正式场景配置中的目标系数仍需显式确定。smoke 配置只用于验证，不能作为正式调参或定位效果证据。本机已验证 CPU 流程，GPU 与正式参数尚待验收。

相关说明：[数据](docs/data-contract.md)、[训练目标](docs/training-objective.md)、[GNN/采样](docs/gnn-sampling.md)、[粒子 BP](docs/particle-bp.md)、[第六步验收](docs/stage6-verification.json)、[第七步验收](docs/stage7-verification.json)。
